/* Disable minification (remove `.min` from URL path) for more info */


typeof polyfillServiceCallbackpvjscustomelement==='function' && polyfillServiceCallbackpvjscustomelement();