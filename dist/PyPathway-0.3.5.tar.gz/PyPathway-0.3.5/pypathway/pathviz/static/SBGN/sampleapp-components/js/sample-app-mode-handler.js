var modeHandler = {
  mode: "selection-mode"
};