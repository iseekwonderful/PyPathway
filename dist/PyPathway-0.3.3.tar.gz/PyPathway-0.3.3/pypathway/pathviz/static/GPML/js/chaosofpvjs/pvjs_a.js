/**
 * Created by sheep on 16/11/16.
 */
/* Disable minification (remove `.min` from URL path) for more info */


typeof polyfillServiceCallbackpvjscore==='function' && polyfillServiceCallbackpvjscore();