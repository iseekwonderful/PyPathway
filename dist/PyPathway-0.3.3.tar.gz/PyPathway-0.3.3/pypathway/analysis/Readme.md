The Network Enrichment Analysis and the Network based modelling method

# Set base enrichment analysis: ORA GSEA
# Network based enrichment analysis: SPIA, Enrichnet

# network modelling method: MIGA, Hotnet2