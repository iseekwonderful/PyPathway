import unittest


class AnalysisTest(unittest.TestCase):
    # test ora
    # test KEGG
    def testKEGGORA(self):
        pass

    # test Go
    def testGOORA(self):
        pass

    # test Reactome
    def testReactomeORA(self):
        pass

    # test gsea
    def testKEGGGSEA(self):
        pass

    def testGOGSEA(self):
        pass

    def testReactomeGSEA(self):
        pass

    def testSPIA(self):
        pass

    def testEnrichnet(self):
        pass

    def testHotNet2Integrate(self):
        pass

    def testMAGIIntegrate(self):
        pass

    def testIntegrateAnalysis(self):
        pass


class VisualizationTest(unittest.TestCase):
    def testExportNotebooks(self):
        pass

    def testExportStaticPage(self):
        pass

    def testExportDjangoProject(self):
        pass
